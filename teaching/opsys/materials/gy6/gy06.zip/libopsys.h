#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

#include <sys/time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>

// gy 2 - signal
#include <signal.h>

#include <sys/ipc.h>
#include <sys/msg.h>

#include <sys/shm.h>

#include <stdbool.h>
#include <semaphore.h>
#include <sys/sem.h>

#ifndef LIBOPSYS_H
#define LIBOPSYS_H


#define atoi DO_NOT_USE


#endif //LIBOPSYS_H