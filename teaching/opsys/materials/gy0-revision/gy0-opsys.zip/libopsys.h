#ifndef LIBOPSYS_H
#define LIBOPSYS_H

// C Util függvények


#endif //LIBOPSYS_H